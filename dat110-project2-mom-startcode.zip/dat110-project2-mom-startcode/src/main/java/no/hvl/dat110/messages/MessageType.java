package no.hvl.dat110.messages;

public enum MessageType {

	CONNECT, DISCONNECT, SUBSCRIBE, UNSUBSCRIBE, PUBLISH, CREATETOPIC, DELETETOPIC, STATUS;
	
}
